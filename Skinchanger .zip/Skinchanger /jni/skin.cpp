

#include "skin.hpp"

#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cstdint>
#include <unistd.h>
#include <dirent.h>
#include <sys/uio.h>
#include <sys/syscall.h>
#include <vector>
#include "protect/oxorany.hpp"

static const char* PACKAGE = "com.axlebolt.standoff2";

static int GetPID(const char* name) {
    DIR* dir = opendir("/proc");
    if (!dir) return -1;
    struct dirent* entry;
    char path[64], cmdline[256];
    int found = -1;
    while ((entry = readdir(dir))) {
        int id = atoi(entry->d_name);
        if (id <= 0) continue;
        snprintf(path, sizeof(path), "/proc/%d/cmdline", id);
        FILE* fp = fopen(path, "r");
        if (!fp) continue;
        memset(cmdline, 0, sizeof(cmdline));
        size_t n = fread(cmdline, 1, sizeof(cmdline) - 1, fp);
        fclose(fp);
        if (n == 0) continue;
        if (strstr(cmdline, name)) { found = id; break; }
    }
    closedir(dir);
    return found;
}

static bool memRead(int pid, uint64_t addr, void* buf, size_t sz) {
    struct iovec local  = { buf,         sz };
    struct iovec remote = { (void*)addr, sz };
    return syscall(SYS_process_vm_readv, pid, &local, 1, &remote, 1, 0) == (ssize_t)sz;
}

static bool memWrite(int pid, uint64_t addr, const void* buf, size_t sz) {
    struct iovec local  = { (void*)buf,  sz };
    struct iovec remote = { (void*)addr, sz };
    return syscall(SYS_process_vm_writev, pid, &local, 1, &remote, 1, 0) == (ssize_t)sz;
}

static void buildPattern(int value, uint8_t pattern[8]) {
    pattern[0] = (uint8_t)( value        & 0xFF);
    pattern[1] = (uint8_t)((value >>  8) & 0xFF);
    pattern[2] = (uint8_t)((value >> 16) & 0xFF);
    pattern[3] = (uint8_t)((value >> 24) & 0xFF);
    pattern[4] = 0x01;
    pattern[5] = 0x00;
    pattern[6] = 0x00;
    pattern[7] = 0x00;
}

static std::vector<uint64_t> scanMemory(int pid, const uint8_t pattern[8]) {
    std::vector<uint64_t> results;

    char mapsPath[64];
    snprintf(mapsPath, sizeof(mapsPath), "/proc/%d/maps", pid);
    FILE* maps = fopen(mapsPath, "r");
    if (!maps) return results;

    const size_t CHUNK = 4 * 1024 * 1024;
    uint8_t* buf = (uint8_t*)malloc(CHUNK);
    if (!buf) { fclose(maps); return results; }

    char line[512];
    while (fgets(line, sizeof(line), maps)) {
        if (!strchr(line, '\n')) {
            int c; while ((c = fgetc(maps)) != '\n' && c != EOF) {}
        }

        uint64_t rs, re;
        char perms[8] = {};
        if (sscanf(line, "%llx-%llx %7s",
                   (unsigned long long*)&rs,
                   (unsigned long long*)&re,
                   perms) < 3) continue;

        if (!strstr(perms, "rw")) continue;

        uint64_t regionSize = re - rs;
        if (regionSize < 8) continue;

        for (uint64_t off = 0; off < regionSize; off += CHUNK) {
            size_t toRead = regionSize - off;
            if (toRead > CHUNK) toRead = CHUNK;
            if (toRead < 8) break;

            if (!memRead(pid, rs + off, buf, toRead)) continue;

            for (size_t i = 0; i + 8 <= toRead; i++) {
                if (buf[i]     == pattern[0] && buf[i + 1] == pattern[1] &&
                    buf[i + 2] == pattern[2] && buf[i + 3] == pattern[3] &&
                    buf[i + 4] == pattern[4] && buf[i + 5] == pattern[5] &&
                    buf[i + 6] == pattern[6] && buf[i + 7] == pattern[7]) {
                    results.push_back(rs + off + i);
                }
            }
        }
    }

    fclose(maps);
    free(buf);
    return results;
}

void change_skin_value(int searchValue, int newValue) {
    int pid = GetPID(PACKAGE);
    if (pid <= 0) return;

    uint8_t pattern[8];
    buildPattern(searchValue, pattern);

    std::vector<uint64_t> candidates = scanMemory(pid, pattern);
    if (candidates.empty()) return;

    std::vector<uint64_t> verified;
    for (uint64_t addr : candidates) {
        int readVal = 0;
        if (memRead(pid, addr, &readVal, sizeof(int)) && readVal == searchValue)
            verified.push_back(addr);
    }
    if (verified.empty()) return;

    for (uint64_t addr : verified)
        memWrite(pid, addr, &newValue, sizeof(int));
}