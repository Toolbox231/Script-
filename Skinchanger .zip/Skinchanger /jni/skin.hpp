#pragma once
void change_skin_value(int searchValue, int newValue);