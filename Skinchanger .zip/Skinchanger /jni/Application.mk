# arm64 + armeabi-v7a — покрывает все современные Android-устройства
APP_ABI      := arm64-v8a

# минимальный API. 21 = Android 5.0.
APP_PLATFORM := android-21

# используем libc++ (современный стандартный C++ runtime NDK)
APP_STL      := c++_static

# сборка без PIE-запрета (для EXECUTABLE Android требует PIE, ndk-build ставит его сам)
APP_PIE      := true