LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE    := skinchanger
LOCAL_SRC_FILES := main.cpp skin.cpp protect/oxorany.cpp

LOCAL_C_INCLUDES := $(LOCAL_PATH)/protect
LOCAL_CPPFLAGS   := -std=c++17 -O2 -fexceptions -frtti -Wall

LOCAL_LDFLAGS    := -Wl,-z,now

include $(BUILD_EXECUTABLE)