
#include "skin.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <dirent.h>
#include <iostream>
#include <string>
#include "protect/oxorany.hpp"

static const char* PACKAGE = "com.axlebolt.standoff2";

static int GetPID(const char* name) {
    DIR* dir = opendir("/proc");
    if (!dir) return -1;
    struct dirent* entry;
    char path[64], cmdline[256];
    int found = -1;
    while ((entry = readdir(dir))) {
        int id = atoi(entry->d_name);
        if (id <= 0) continue;
        snprintf(path, sizeof(path), "/proc/%d/cmdline", id);
        FILE* fp = fopen(path, "r");
        if (!fp) continue;
        memset(cmdline, 0, sizeof(cmdline));
        size_t n = fread(cmdline, 1, sizeof(cmdline) - 1, fp);
        fclose(fp);
        if (n == 0) continue;
        if (strstr(cmdline, name)) { found = id; break; }
    }
    closedir(dir);
    return found;
}

static int waitForGame() {
    std::cout << oxorany("Ищу процесс ") << PACKAGE << " ...\n";
    int pid = GetPID(PACKAGE);
    if (pid > 0) {
        std::cout << oxorany("Нашёл. PID = ") << pid << "\n";
        return pid;
    }
    std::cout << oxorany("Игра не запущена. Жду...\n");
    while (pid <= 0) {
        usleep(1000000);
        pid = GetPID(PACKAGE);
    }
    std::cout << oxorany("Обнаружил игру. PID = ") << pid << "\n";
    return pid;
}

int main(int argc, char** argv) {
    std::cout << oxorany("========================================\n");
    std::cout << oxorany(" Standoff 2 skin changer\n");
    std::cout << oxorany("========================================\n\n");

    int oldId = 0, newId = 0;

    if (argc >= 3) {
        oldId = atoi(argv[1]);
        newId = atoi(argv[2]);
        std::cout << oxorany("Режим аргументов: ") << oldId << " -> " << newId << "\n";
    } else {
        std::cout << oxorany("Введите СТАРЫЙ ID скина: ");
        std::cin >> oldId;
        std::cout << oxorany("Введите НОВЫЙ ID скина: ");
        std::cin >> newId;
    }
    waitForGame();

    std::cout << oxorany("\nМеняю ") << oldId << oxorany(" -> ") << newId << " ...\n";
    change_skin_value(oldId, newId);
    std::cout << oxorany("Готово.\n");

    std::cout << oxorany("\nНажми Enter для выхода...\n");
    std::cin.ignore();
    std::cin.get();
    return 0;
}